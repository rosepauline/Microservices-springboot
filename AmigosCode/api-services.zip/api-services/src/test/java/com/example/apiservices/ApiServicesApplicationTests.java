package com.example.apiservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
